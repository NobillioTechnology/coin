

import React, { Component } from 'react';
import {
  Text, View, Image, TextInput, TouchableHighlight, BackHandler, ActivityIndicator, FlatList
} from 'react-native';
import Styles from './style'
import Header from '../Header'
import ScrollableTabView,{ScrollableTabBar } from 'react-native-scrollable-tab-view';
import Icon from 'react-native-vector-icons/FontAwesome';
import Footer from '../Footer';
import Utils from '../Utils';
import CustomDialog from '../CustomDialog';
import RadioForm from 'react-native-simple-radio-button';
import Adapter from './Adapter';
import RNPickerSelect from 'react-native-picker-select';
import WebAPi from '../../Common/WebApi';
import ProgressBar from '../ProgressBar';
import DropDown from '../DropDown';


export default class Home extends Component {


  constructor(props) {
    super(props);
 
        this.openProfile=this.openProfile.bind(this);
         this.buyButton=this.buyButton.bind(this);
         this.sellButton=this.sellButton.bind(this);
         this.stopLoading=this.stopLoading.bind(this);
         this.handleBack=this.handleBack.bind(this);
         this.closeDrop=this.closeDrop.bind(this);
         this.chooseDropItem=this.chooseDropItem.bind(this);
         
      this.state={
        title:'Buy Bitcoin', 
        role:'Buy', type:'buy',
        loading:false,
        loadingTitle:'Please Wait',
        loadingMessage:"Loading...",
        loadingMore:true, refreshing:false, loadingDisabled:false,
        dataSource:[], page:1, dropDown:false, currentDrop:'', dropItems:[],
        _id:'',
        filter:false, amount:'', currency:'Select currency', country:'Select country', offer:'All Online Offers', offersData:[]
      }
   }

   componentDidMount=async()=>{
     BackHandler.addEventListener('hardwareBackPress', this.handleBack);
     const role = await this.props.navigation.getParam('role', 'Buy');
     var type = 'buy';
     if(role==='Sell')
         this.setState({type:'sell'});
       this.getOffers();
      await this.getTradeList(this.state.page);
   }

   componentWillUnmount(){
     BackHandler.removeEventListener('hardwareBackPress', this.handleBack);
   }

   handleBack(){
     this.props.navigation.goBack(null);
     return true;
   }
  
  openProfile(id){
    this.props.navigation.navigate('UserDetails', {_id:id});
  }

  buyButton(id){
    this.props.navigation.navigate('BuyTrade', { id:id, role:this.state.role});
  }

  sellButton(id){
   this.props.navigation.navigate('BuyTrade', {id:id, role:this.state.role});
   }

  stopLoading(){
   this.setState({loading:false});
   }

   getOffers=async()=>{
     await WebAPi.getApi_trade('paymentMethodList')
           .then(response => response.json())
            .then(json => {
                 // console.log('Response from filter trade===>', json);
                    if(json.responseCode==200){
                        // console.log('Modified Offers=====>', json.result)
                      var data = this.state.offersData;
                      if(json.result.length>0){
                          json.result.map((item)=>{
                            data.push({label:item.name, value:item.name, color:'#000'});
                            this.setState({
                              offersData:data,
                            });
                          })
                        }
                      }else{
                      this.setState({loading:true, loadingTitle:'Alert', loadingMessage:json.responseMessage});
                    }
                })
                .catch(error => {
                  console.log('error==>' , error)
                  this.setState({loading:true, refreshing:false,
                                loadingTitle:'Alert',
                                loadingMessage:'Oops! '+error,
                      })
          });

   }

   getTradeList=async(pageNumber)=>{
         if(pageNumber==1)
           this.setState({dataSource:[]});
         this.setState({refreshing:true});

         const body= JSON.stringify({
                        amount:this.state.amount,
                        currency_type:this.state.currency,
                        location:this.state.country,
                        payment_method:this.state.offer,
                        type:this.state.type,
                        page:pageNumber,
                        limit:10
                    });
         await WebAPi.postApi_WT_trade('filter_trade', body)
          .then(response => response.json())
            .then(json => {
             this.setState({refreshing:false, loadingMore:false});
                 console.log('Response from filter trade===>', json.result);
                    if(json.responseCode==200){
                        // console.log('Modified json=====>', json.result.docs)
                      var data = this.state.dataSource;
                      if(json.result.docs.length>0){
                          json.result.docs.map((item)=>{
                            data.push(item);
                            this.setState({
                              dataSource:data,
                            });
                          })
                        }else
                            this.setState({refreshing:false, loadingMore:false, dataSource:[]});
                    }else if(json.responseCode==401){
                            this.setState({refreshing:false, loadingMore:false, loadingDisabled:true});                      
                    }else{
                      this.setState({loading:true, loadingTitle:'Alert', loadingMessage:json.responseMessage});
                    }
                })
                .catch(error => {
                  console.log('error==>' , error)
                  this.setState({loading:true, refreshing:false,
                                loadingTitle:'Alert',
                                loadingMessage:'Oops! '+error,
                      })
          });
   }

   openDrop(dropType){
     if(dropType=='currency')
       this.setState({currentDrop:'currency', dropDown:true, dropItems:Utils.currency});
     else if(dropType=='country')
       this.setState({currentDrop:'country', dropDown:true, dropItems:Utils.country});
     else if(dropType=='offer')
       this.setState({currentDrop:'offer', dropDown:true, dropItems:this.state.offersData});
  }
   chooseDropItem(item){
     if(this.state.currentDrop=='currency')
         this.setState({dropDown:false, currency:item.value});
     else if(this.state.currentDrop=='country')
         this.setState({dropDown:false, country:item.value});
     else if(this.state.currentDrop=='offer')
         this.setState({dropDown:false, offer:item.value});
   }

    loadMore=()=>{
          this.setState(
            (prevState, nextProps) => ({
              page: prevState.page + 1,
              loadingMore: true
            }),
            async() => {
              console.log('loading more===>', this.state.loadingDisabled, this.state.page);
              if(!this.state.refreshing)
                await this.getTradeList(this.state.page);
            }
          );
  };

  _renderFooter = () => {
    if (!this.state.loadingMore) return null;

    return (
      <View
        style={{
          position: 'relative',
          width: '100%',
          height: 50,
          paddingVertical: 20,
          marginVertical:10,
        }}
      >
        <ActivityIndicator animating size="large" />
      </View>
    )
  }

  closeDrop(){
    this.setState({DropDown:false});
  }


  render() {

      const role = this.props.navigation.getParam('role', 'Buy');
        if(role!=this.state.role){
          this.setState({role:role});
        }
        if(this.state.role=='Sell')
          if(this.state.title!='Sell Bitcoin')
              this.setState({title:'Sell Bitcoin'});
    
    return (
      <View style={Styles.body}>
       <Header title={this.state.title} menuCheck="false" data={this.props} style={Styles.header}/>
       <ProgressBar
          title={this.state.loadingTitle}
          message={this.state.loadingMessage}
          visible={this.state.loading}
          close={this.stopLoading}
        />
        <DropDown
          close={this.closeDrop}
          dropdown={this.state.dropDown}
          items={this.state.dropItems}
          choose={this.chooseDropItem}
        />
           <View style={Styles.container}>
                <View style={{margin:10}}>
                  <View style={{flexDirection:'row', height:40}}>
                    <TextInput style={Styles.editText}
                      placeholder="Enter Amount"
                      keyboardType={'numeric'}
                      value={this.state.amount}
                      onChangeText={(val)=>this.setState({amount:val})}
                      />
                  <TouchableHighlight style={Styles.editTextRight} onPress={()=>this.openDrop('currency')} underlayColor='none'>
                    <View>
                      <Text style={this.state.currency=='Select currency' ? Styles.placeholder : Styles.dropItemSelected}>{this.state.currency}</Text>
                      <Icon name='sort-down' style={Styles.dropIcon}/>
                    </View>
                  </TouchableHighlight>
                  </View> 
                  <View style={{flexDirection:'row', height:40, marginTop:10}}>
                  <TouchableHighlight style={Styles.editText} onPress={()=>this.openDrop('country')} underlayColor='none'>
                    <View>
                      <Text style={this.state.country=='Select country' ? Styles.placeholder : Styles.dropItemSelected}>{this.state.country}</Text>
                      <Icon name='sort-down' style={Styles.dropIcon}/>
                    </View>
                  </TouchableHighlight>
                  <TouchableHighlight style={Styles.editTextRight} onPress={()=>this.openDrop('offer')} underlayColor='none'>
                    <View>
                      <Text style={this.state.offer=='All Online Offers' ? Styles.placeholder : Styles.dropItemSelected}>{this.state.offer}</Text>
                      <Icon name='sort-down' style={Styles.dropIcon}/>
                    </View>
                  </TouchableHighlight>
                  </View>
                  <TouchableHighlight style={Styles.submit} onPress={()=>{this.getTradeList(1)}}>
                     <Text style={{fontSize:Utils.headSize+2}}>Search</Text>
                  </TouchableHighlight>
                </View>
                {this.state.role=='Buy' && (
                  <View style={{marginBottom:15}}>
                      <FlatList
                        data={ this.state.dataSource}
                        renderItem={ ({item}) =>
                          <View>
                            <Adapter
                            id={item._id}
                            userId={item.user_id}
                            username={item.user_name}
                            bitcoin={parseFloat(item.price_equation).toFixed(8)}
                            role={this.state.role}
                            text1label={parseFloat(item.toPay).toFixed(8)}
                            paymentMethod={item.payment_method}
                            limit={item.min_transaction_limit+ '-' +item.max_transaction_limit}
                            userProfile={this.openProfile}
                            status={item.userStatus}
                            buyButton={this.buyButton}
                            />
                          </View>
              
                       }                          
                      numColumns={1}
                      onEndReached={()=>{if(!this.state.loadingDisabled) this.loadMore();}}
                      onEndReachedThreshold={1}
                      initialNumToRender={10}
                      ListFooterComponent={this._renderFooter}
                      onRefresh={()=>this.getTradeList(1)}
                      refreshing={this.state.refreshing}
                      />
                  </View>
                )}

            {this.state.role=='Sell' && (
              <View>
              <FlatList
                    data={ this.state.dataSource}
                    renderItem={ ({item}) =>
                      <View>
                        <Adapter
                          id={item._id}
                          username={item.user_name}
                          bitcoin={parseFloat(item.price_equation).toFixed(8)}
                          role={this.state.role}
                          text1label={parseFloat(item.toPay).toFixed(8)}
                          paymentMethod={item.payment_method}
                          limit={item.min_transaction_limit+ '-' +item.max_transaction_limit}
                          userProfile={this.openProfile}
                          status={item.userStatus}
                          sellButton={this.sellButton}
                          currency={item.currency_type}
                          />
                      </View>
                    }                          
                numColumns={1}
                onEndReached={()=>{if(!this.state.loadingDisabled) this.loadMore();}}
                onEndReachedThreshold={1}
                initialNumToRender={10}
                ListFooterComponent={this._renderFooter}
                onRefresh={()=>this.getTradeList(1)}
                refreshing={this.state.refreshing}
                />
              </View>
            )}
          </View>
      </View>
    );
  }
}
