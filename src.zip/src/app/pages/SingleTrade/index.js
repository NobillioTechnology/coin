import React, { Component } from 'react';
import {
  Text, View, Image, TextInput, ScrollView, TouchableHighlight, BackHandler, Modal, Dimensions
} from 'react-native';
import Styles from './style'
import Header from '../Header'
import Icon from 'react-native-vector-icons/FontAwesome';
import Utils from '../Utils';
import CustomDialog from '../CustomDialog';
import CountDown from 'react-native-countdown-component';
import WebApi from '../../Common/WebApi';
import ProgressBar from '../ProgressBar';
import RadioForm from 'react-native-simple-radio-button';
import HTML from 'react-native-render-html';

var radio_props = [
  {label: 'Incorrect trade amount', value: 'Incorrect trade amount' },
  {label: 'Seller did not respond', value: 'Seller did not respond' },
  {label: 'Trade terms did not match', value: 'Trade terms did not match' },
  {label: 'Reason not listed', value: 'Reason not listed' },

];

export default class SingleTrade extends Component {


  constructor(props) {
    super(props);
          
      this.state={
        title:'Trade', 
        status:'pending',
        timer: 120,
        timerState:false,
        tradeId:'',
        loading:false,
        loadingTitle:'Please Wait',
        loadingMessage:"Loading...",
        uniqueTradeId:'', selling:'', amount:'', currency:'', adId:'', paymentMethod:'', exchangeRate:'', tradeStatus:'',
        remainingTime:0, ad_id:'', paidStatus:false, tradeOwner:'', myName:'', terms:'', shownTerms:false,
        paymentButtonLine:'I have paid',
        cancelModal:false, reason:'Incorrect trade amount', customReason:false, validCustomReason:true
      }
      this.startTimer=this.startTimer.bind(this);
      this.stopLoading=this.stopLoading.bind(this);
      this.handleBack=this.handleBack.bind(this);
   }

   componentDidMount(){
     BackHandler.addEventListener('hardwareBackPress', this.handleBack);
     const tradeId = this.props.navigation.getParam('tradeId', '1');
     this.setState({tradeId:tradeId});
     this.getTradeDetails(tradeId);
   }

   componentWillUnmount(){
     BackHandler.removeEventListener('hardwareBackPress', this.handleBack);
   }

   handleBack(){
     this.props.navigation.goBack(null);
     return true;
   }

   stopLoading(){
     if(this.state.loading)
       this.setState({loading:false});
   }

   getTradeDetails=async(tradeId)=>{
     this.setState({loading:true});
     const body = JSON.stringify({
                     tradeId:tradeId,
                   })
         console.log(tradeId);
         await WebApi.postApi_trade('treadeDetails', body)
          .then(response => response.json())
            .then(json => {
               this.setState({loading:false});
                 console.log('Response from tradeDetails===>', json);
                    if(json.responseCode==200){
                        var selling = json.result.amount_of_cryptocurrency;
                        selling= Number.parseFloat((selling=='') ? 0 : selling).toFixed(8);
                        if(json.result!==null){
                          if(json.result.trade_type=='sell')
                            this.setState({paymentButtonLine:'Release BTC'});
                          this.setState({
                            timer:json.result.payment_window_time,
                            uniqueTradeId:json.result.uniqueId,
                            selling:selling,
                            amount:json.result.amount_in_currency,
                            currency:json.result.currency_type,
                            adId:json.result.addUniqueId,
                            paymentMethod:json.result.payment_method,
                            exchangeRate:json.result.exchangeRate,
                            tradeStatus:json.result.status,
                            remainingTime:json.result.remainingPaymentTime,
                            ad_id:json.result.advertisement_id,
                            paidStatus:json.result.paid_status,
                            tradeOwner:json.result.advertisement_owner_name,
                            myName:json.result.trade_owner_name
                          });
                          this.startTimer(this.state.remainingTime);
                        }
                    }else{
                      this.setState({loading:true, loadingTitle:'Alert', loadingMessage:json.responseMessage});
                    }
                })
          .catch(error => {
            console.log('error==>' , error)
            this.setState({loading:true,
                          loadingTitle:'Alert',
                          loadingMessage:'Oops! '+error,
                })
          });
         await WebApi.getApi_trade('detail_trade/'+this.state.ad_id)
          .then(response => response.json())
            .then(json => {
               this.setState({loading:false});
                 console.log('Response from tradeDetails==2====>', json);
                    if(json.responseCode==200){
                        this.setState({terms:json.result.terms_of_trade});
                        // alert(this.state.terms);
                    }else{
                      this.setState({loading:true, loadingTitle:'Alert', loadingMessage:json.responseMessage});
                    }
                })
          .catch(error => {
            console.log('error==>' , error)
            this.setState({loading:true,
                          loadingTitle:'Alert',
                          loadingMessage:'Oops! '+error,
                })
          });
        }

   havePaid=async()=>{

     if(this.state.paymentButtonLine=='Release BTC'){
         this.releaseBTC();
         return;
        }
         this.setState({loading:true});
         const body = JSON.stringify({
                     advertisementId:this.state.ad_id,
                     notificationType:'ihavepaid',
                     paid_status:true,
                     request_status:'Paid',
                     status:'PAID',
                     tradeId:this.state.tradeId
                   })
         await WebApi.postApi_trade('iHavePaidTrade', body)
          .then(response => response.json())
            .then(json => {
               this.setState({loading:false});
                 console.log('Response from havePaid===>', json);
                    if(json.responseCode==200){
                        // console.log('Modified json=====>', json.result)
                        if(json.result!==null){
                          this.setState({
                            timer:json.result.payment_window_time,
                            uniqueTradeId:json.result.uniqueId,
                            selling:json.result.amount_of_cryptocurrency,
                            amount:json.result.amount_in_currency,
                            currency:json.result.currency_type,
                            adId:json.result.addUniqueId,
                            paymentMethod:json.result.payment_method,
                            exchangeRate:json.result.exchangeRate,
                            tradeStatus:json.result.status,
                            remainingTime:json.result.remainingPaymentTime,
                            ad_id:json.result.advertisement_id,
                            paidStatus:json.result.paid_status,
                            tradeOwner:json.result.advertisement_owner_name,
                            myName:json.result.trade_owner_name
                          });
                          this.startTimer(this.state.remainingTime);                          
                        }
                    }else{
                      this.setState({loading:true, loadingTitle:'Alert', loadingMessage:json.responseMessage});
                    }
                })
                .catch(error => {
                  console.log('error==>' , error)
                  this.setState({loading:true,
                                loadingTitle:'Alert',
                                loadingMessage:'Oops! '+error,
                      })
          });
   }

   releaseBTC(){
     if(this.state.paidStatus==false)
         this.setState({loading:true, loadingTitle:'Alert', loadingMessage:"Buyer's did not confirm any payment"});
      else{
       this.setState({loading:true, loadingTitle:'Please Wait', loadingMessage:'Releasing...'});
        var body = JSON.stringify({
            "tradeId": this.state.ad_id,
            "received_status": "true",
            "request_status": "Complete",
            "status": "COMPLETE"
        })
        WebApi.postApi_trade('paymentReceived', body)
          .then(response => response.json())
            .then(json => {
               this.setState({loading:false});
                 console.log('Response from releaseBTC===>', json);
                    if(json.responseCode==200){
                        console.log('Modified json=====>', json.result)
                        if(json.result!==null){
                          this.setState({
                            timer:json.result.payment_window_time,
                            uniqueTradeId:json.result.uniqueId,
                            selling:json.result.amount_of_cryptocurrency,
                            amount:json.result.amount_in_currency,
                            currency:json.result.currency_type,
                            adId:json.result.addUniqueId,
                            paymentMethod:json.result.payment_method,
                            exchangeRate:json.result.exchangeRate,
                            tradeStatus:json.result.status,
                            remainingTime:json.result.remainingPaymentTime,
                            ad_id:json.result.advertisement_id,
                            paidStatus:json.result.paid_status,
                            tradeOwner:json.result.advertisement_owner_name,
                            myName:json.result.trade_owner_name
                          });
                          this.startTimer(this.state.remainingTime);                          
                        }
                    }else{
                      this.setState({loading:true, loadingTitle:'Alert', loadingMessage:json.responseMessage});
                    }
                })
                .catch(error => {
                  console.log('error==>' , error)
                  this.setState({loading:true,
                                loadingTitle:'Alert',
                                loadingMessage:'Oops! '+error,
                      })
          });


      }
   }

  cancelTrade=async()=>{
    if(this.state.reason!='' && this.state.validCustomReason){
        this.setState({cancelModal:false, loading:true, loadingTitle:'Please Wait', loadingMessage:'Cancelling...'});
        const body = JSON.stringify({
                      advertisementId:this.ad_id,
                      reason:this.state.reason,
                      tradeId:this.state.tradeId
                    });
        await WebApi.postApi_trade('cancelTrade', body)
        .then(response => response.json())
            .then(json => {
               this.setState({loading:false});
                 console.log('Response from havePaid===>', json);
                    if(json.responseCode==200){
                        // console.log('Modified json=====>', json.result)
                        if(json.result!==null){
                          this.getTradeDetails(this.state.tradeId);
                        }
                    }else{
                      this.setState({loading:true, loadingTitle:'Alert', loadingMessage:json.responseMessage});
                    }
                })
                .catch(error => {
                  console.log('error==>' , error)
                  this.setState({loading:true,
                                loadingTitle:'Alert',
                                loadingMessage:'Oops! '+error,
                      });
                })
    }else
      this.setState({validCustomReason:false});
  }

   startTimer(ms){
     if(this.state.timerState!=true){
        this.setState({timerState:true, timer:ms});
        this.interval = setInterval(()=>{
              this.setState({
                  timer: --this.state.timer
              })
          }, 1000);
      }
   }
  render() {

    return (
      <View style={Styles.body}>
       <Header title={this.state.title} menuCheck="false" data={this.props} style={Styles.header}/>
       <ProgressBar
            title={this.state.loadingTitle}
            message={this.state.loadingMessage}
            visible={this.state.loading}
            close={this.stopLoading}
          />
        <ScrollView style={{flex:0.8}} keyboardShouldPersistTaps={'always'}>
          <View style={Styles.container}>
            <View style={{marginBottom:15, backgroundColor:Utils.colorWhite}}>
              <Text style={[Styles.heading, {alignSelf:'center', width:'90%'}]}>Trade ID {this.state.uniqueTradeId} :Selling {this.state.selling} bitcoins for {this.state.amount} {this.state.currency}</Text>
              <Text style={[Styles.subHeading, {alignSelf:'center', width:'90%'}]}>Buying from advertisement {this.state.adId} with ({this.state.currency}) at the exchange rate of {this.state.exchangeRate} {this.state.currency}/BTC</Text>
              <View style={Styles.borderView}>
                <Text style={Styles.itemlebalBold}>Trade Status: <Text style={{fontWeight:'normal'}}>{this.state.tradeStatus}</Text></Text>
              </View>
              </View>
              {(() => {
                if(this.state.tradeStatus === 'PAID' || this.state.tradeStatus ==='PENDING'){
                  return(
                      <View style={[Styles.itemBody, {marginTop:10, marginBottom:10}]}>
                        <Text style={[Styles.heading, {marginTop:20}]}>Payment Confirmation</Text>              
                        <Text style={[Styles.subHeading, {alignSelf:'center', width:'90%'}]}>Once you have made payment make sure you click on "I have paid" button. Otherwise the trade will get timed out and gets cancelled automatically and bitcoins will return to the vendor.</Text>
                        {this.state.paidStatus===false ? (
                          <View>
                            <TouchableHighlight underlayColor='none' onPress={()=>this.havePaid()}>
                              <View style={[Styles.borderView, Styles.buttonGreen]}>
                                <Text style={Styles.buttonGreen}>{this.state.paymentButtonLine}</Text>
                              </View>
                            </TouchableHighlight>
                          </View>
                          ):(
                            <View style={[Styles.borderView, Styles.buttonGreenDisabled]}>
                              <Text style={{color:'#00000077'}}>Paid</Text>
                            </View>
                          )}
                        {this.state.timerState==true && (
                          <View style={{alignSelf:'flex-start', marginLeft:20, marginTop:-15, marginBottom:10}}>
                          <CountDown
                            until={this.state.timer}
                            size={15}
                            onFinish={() => this.setState({timerState:false})}
                            digitStyle={{marginHorizontal:-5}}
                            digitTxtStyle={{color: Utils.colorGreen, marginBottom:-20}}
                            timeToShow={['D',':','H',':', 'M',':', 'S']}
                            timeLabels={{d:'DD', h:'HH', m: 'MM', s: 'SS'}}
                          />
                          </View>
                        )}
                      </View>
                  )}
                })()}
              <View style={[Styles.itemBody, {marginTop:10, marginBottom:10}]}>
                <Text style={[Styles.heading, {marginTop:20}]}>Having Trading issue?</Text>              
                <Text style={[Styles.subHeading, {alignSelf:'center', width:'90%'}]}>You can always cancel the trade if it was started by mistake, or if you dont meet the requirements mentioned in the trade instructions.</Text>
                {this.state.tradeStatus==='CANCEL' ? (
                <TouchableHighlight style={[Styles.borderView, Styles.buttonRed]}>
                  <Text style={Styles.buttonRed}>Trade cancelled</Text>
                </TouchableHighlight>
                ):(
                <TouchableHighlight style={[Styles.borderView, Styles.buttonGreen]} 
                  onPress={()=>this.setState({cancelModal:true})}
                  underlayColor='none'
                  >
                  <Text style={Styles.buttonGreen}>Cancel the purchase</Text>
                </TouchableHighlight>
                )}
              </View>
              
              <View style={[Styles.itemBody, {marginTop:10, marginBottom:20}]}>
                <View style={{flexDirection:'row', alignItems:'center', justifyContent:'center'}}>
                  <Text style={[Styles.heading, {flex:0.8, marginTop:-10}]}>Send message to {this.state.tradeOwner}</Text>              
                  <TouchableHighlight style={[Styles.borderView, Styles.submitButton, {borderWidth:0, width:'35%'}]}
                      onPress={()=>this.setState({shownTerms:true})}
                    >
                    <Text>Terms Of Trade</Text>
                  </TouchableHighlight> 
                </View>
                <ScrollView style={{minHeight:250}}>
                  <View style={Styles.myMessage}>
                    <Text>Buy trade request from {this.state.myName}</Text>
                  </View>
                  <Text style={Styles.myMessageTime}>Tue May 12 2020 22:02:18</Text>
                </ScrollView>
                  <View style={{marginTop:10, flexDirection:'row', width:'90%', alignSelf:'center'}}>
                    <TextInput 
                      style={[Styles.borderView, {flex:0.8, marginTop:0, paddingLeft:10}]}
                      placeholder="Enter your message here"
                      />
                    <View style={[Styles.submitButton, {flex:0.2, marginLeft:5}]}>
                      <Text>Send</Text>
                    </View>
                  </View>
                <View style={[Styles.borderView, {alignItems:'flex-start'}]}>
                  <Text style={{marginLeft:20}}>Upload</Text>
                  <Icon name='paperclip' style={{position:'absolute', right:10, fontSize:20}}/>
                </View>
              </View>
          </View>
        </ScrollView>
        <Modal style={[Styles.dialogue]}
            visible={this.state.cancelModal}
            transparent={true}
            animationType={"fade"}
            onRequestClose={ () => { this.setState({cancelModal:false})}}>
               <View style={Styles.dialogue}>
                <View style={Styles.dialogueContainer}>
                    <Icon name='times' style={{position:'absolute', right:10, top:10, fontSize:20}} onPress={()=>this.setState({cancelModal:false})}/>
                    <Text style={Styles.dialogTitle}>Please select the reason for cancelling the trade</Text>
                      <View style={{width:'85%', flex:1, alignSelf:'center'}}>
                      <RadioForm
                        radio_props={radio_props}
                        initial={0}
                        formHorizontal={false}
                        animation={true}
                        onPress={(value) => {this.setState({reason:value, customReason:false}); if(value=='Reason not listed') this.setState({customReason:true, reason:''})}}
                        borderWidth={1}
                        buttonColor={Utils.colorGreen}
                        selectedButtonColor={Utils.colorGreen}
                        buttonSize={10}
                        buttonOuterSize={25}
                        style={{alignSelf:'center', marginTop:10}}
                        labelStyle={{fontSize: Utils.subHeadSize+1}}
                      />
                      {this.state.customReason && (
                      <TextInput
                        style={this.state.validCustomReason ? Styles.dialogueTextArea : Styles.dialogueTextAreaError}
                        value={this.state.reason}
                        onChangeText={(val)=>this.setState({reason:val, validCustomReason:true})}
                        multiline={true}
                        maxLine={9}
                        />
                        )}
                        <TouchableHighlight underlayColor='none' onPress={()=>this.cancelTrade()} style={Styles.dialogueSubmit}>
                          <Text style={{fontSize:Utils.headSize}}>Submit</Text>
                        </TouchableHighlight>
                      </View>
                </View>
              </View>
          </Modal>
        <Modal style={[Styles.dialogue]}
            visible={this.state.shownTerms}
            transparent={true}
            animationType={"fade"}
            onRequestClose={ () => { this.setState({shownTerms:false})}}>
               <View style={Styles.dialogue}>
                <View style={Styles.dialogueContainerTerms}>
                    <Icon name='times' style={{position:'absolute', right:10, top:10, fontSize:20}} onPress={()=>this.setState({shownTerms:false})}/>
                    <Text style={Styles.dialogTitle}>Terms of Trade</Text>
                      <View style={{width:'85%', flex:1, alignSelf:'center'}}>
                        <HTML html={this.state.terms} imagesMaxWidth={Dimensions.get('window').width} style={Styles.longText}/>
                      </View>
                </View>
              </View>
          </Modal>
      </View>
    );
  }
}
