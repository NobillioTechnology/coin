import { StyleSheet } from 'react-native';
import Utils from '../Utils';

export default StyleSheet.create({

itemBody:{
	flexDirection:'row',

},
dialogue:{
		// backgroundColor:'blue',
		alignSelf:'center',
		// minWidth: '80%',
		justifyContent:'center',
		flex:1,
	backgroundColor:'#00000088',
	width:'100%',
	},
	dialogueContainer:{
		width:'90%',
		alignSelf:'center',
		backgroundColor : Utils.colorWhite,
		minHeight:150,
		borderWidth: 1,
		borderColor:Utils.colorGreen,
		borderRadius:17,
	},
	dialogTitle:{
		color:Utils.colorBlack,
		fontSize:Utils.headSize+3,
		marginTop:10,
		marginBottom:15,
		alignSelf:'center',
	},
	dialogueMessage:{
		color:Utils.colorBlack,
		fontSize:Utils.subHeadSize,
		width:'90%',
		marginVertical:10,
		flex:0.8,
		marginBottom:5,
	},
	dialogueMessageAlert:{
		color:Utils.colorBlack,
		fontSize:Utils.subHeadSize,
		width:'90%',
		marginVertical:5,
	},
	ok:{
		alignSelf:'center', 
		marginTop:20,
		backgroundColor:Utils.colorGray,
		width:'50%',
		alignItems:'center',
		justifyContent:'center',
		height:40,
		borderRadius:25
	}

})